#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#define SIZE 4
#define LABELLEN  6
#define EQDATALEN 4
int flag = 0; 
struct eq_data {
    char *all_eqid;
    char *type;
    float range;
	int  sigbits;
};

struct all_data {
    char *all_label;
    struct eq_data validate[EQDATALEN];
};

struct all_data data1[LABELLEN] = {
    {"001", {{"002", "BCD",3999.9,5}, {"056", "BCD",3999.9,5}, {"060", "BCD",3999.9,5}}},
    {"002", {{"002", "BCD",399.9,4}, {"056", "BCD",399.9,4}, {"060", "BCD",399.9,4}, {"115", "BCD",399.9,4}}},
    {"003", {{"002", "BCD",399.9,4}}},
    {"004", {{"001", "BCD",79900,3}}},
    {"025", {{"04D", "BNR",204700,11}}},
	{"164", {{"007", "BNR",8192,16},{"025", "BNR",8192,12},{"003", "BNR",8192,16}}},
};

char *validation(char* label,char* eqid,char *data,float *range,int *sbits)
{
	char* datatype = NULL;
	for(int i=0;i<LABELLEN;i++)
	{
		if(strcmp(data1[i].all_label,label)==0)
		{
			for(int j=0;j<EQDATALEN;j++)
			{
				if(strcmp(data1[i].validate[j].all_eqid,eqid)==0)
				{
					//printf("Valid eqid\n");
					datatype = malloc(sizeof(char)*SIZE);
					strcpy(datatype,data1[i].validate[j].type);
					*range = data1[i].validate[j].range;
					if(atoi(data)>data1[i].validate[j].range)
					{
			            printf("Invalid data! Please enter data in range of %f\n",data1[i].validate[j].range);
						printf("Enter the data :");
						scanf("%s",data);	
					}
					if(strcmp(datatype,"BNR")==0)
					{
						*sbits = data1[i].validate[j].sigbits;
					}
					flag=0;
					break;
				}
				else
				{
					flag=1;
				}
			}
		if(flag==1)
		{
			printf("Invalid eqid\n");
			printf("Enter the Eqid :");//user input equipment ID
    		scanf("%s",eqid);
		}
		break;
		}
	}
	return datatype;
}
