#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include "arinc.h"

uint32_t Final_destination(char *ptr)
{
    uint32_t Ans = 0;
    int pos = strlen(ptr) - 1;
    
    for (int i = 0; i < strlen(ptr); i++)
    {
        int temp = ptr[i] - '0';
        if (temp == 1) {
            Ans = Ans | (1 << pos);
        }
        pos--;
    }
    return Ans;
}

