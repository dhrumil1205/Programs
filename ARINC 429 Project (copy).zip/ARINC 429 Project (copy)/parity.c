#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include "arinc.h"
char ARINC[32];
void paritybit(char* bcd,char* label,char* ssm,char* sdi)
{
	int count=0;
	for(int i=0;i<strlen(bcd);i++)
	{
		if(bcd[i]=='1')
		{
			count++;
		}
	}
	for(int i=0;i<strlen(label);i++)
	{
		if(label[i]=='1')
		{
			count++;
		}
	}
	for(int i=0;i<strlen(ssm);i++)
	{
		if(ssm[i]=='1')
		{
			count++;
		}
	}
	for(int i=0;i<strlen(sdi);i++)
	{
		if(sdi[i]=='1')
		{
			count++;
		}
	}
	if(count%2==0)
		strcat(ARINC,"1");
	else
		strcat(ARINC,"0");

}
