#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include "arinc.h"
#define DBUS_SIZE 19
#define LBUS_SIZE 8
#define userinputdata 6
//char ssm[3],sdi[3];
char ARINC[32];
int ssm=0,sdi=0;

int main() {
    char *label = malloc(sizeof(char)*3);
    char *eqid = malloc(sizeof(char)*3);
    char *bcd=0,*l2BCD=0,*LabelRev=0,*bnr=0;
    float r=0;
    int sigbits=0;
    char data[userinputdata];
    printf("Enter the Data :");//user input data
    scanf("%s",data);
    
    printf("Enter the Eqid :");//user input equipment ID
    scanf("%s",eqid);
    
    printf("Enter the label :");//user input label
    scanf("%s",label);
    
    char* valid = validation(label,eqid,data,&r,&sigbits);//validation of data
    printf("Data Type of data : %s\n",valid);
    printf("Range :%0.2f\n",r);
    printf("Sig Bits :%d\n",sigbits);
    if(strcmp(valid,"BCD")==0)//check wheather data type is BCD or BNR
    {
    	printf("Data type is BCD\n");
    	bcd = deci2BCD(data,DBUS_SIZE);
    }
    else
    {
    	printf("Data type is BNR\n");
    	bnr = deci2BNR(data,r,sigbits);
        printf("BNR Frame :%s\n",bnr);
    }
    
    l2BCD = deci2BCD(label,LBUS_SIZE);//coverting label to BCD
    printf("%s\n",l2BCD);
    
    LabelRev = rev(l2BCD);//Reversing the label
    printf("%s\n",LabelRev);
    
    printf("ARINC 429 SSM Bits (30-31 Bits) :");//user input ssm bits
    scanf("%d",&ssm);
    
    char* Signbits = validssm(data,valid,ssm);
    printf("%s\n",Signbits);

    printf("ARINC 429 SDI Bits(9-10 Bits) :");//user input sdi bits
    scanf("%d",&sdi);
    
    char* Sdi = validsdi(sdi);
    printf("%s\n",Sdi);

    if (strcmp(valid,"BCD")==0)
    {
        paritybit(bcd,LabelRev,Signbits,Sdi);//parity bits(check for odd parity)
        strcat(ARINC,Signbits);
        strcat(ARINC,bcd);
        strcat(ARINC,Sdi);
        strcat(ARINC,LabelRev);
        ARINC[32] = '\0';
    }
    else
    {
        paritybit(bnr,LabelRev,Signbits,Sdi);//parity bits(check for odd parity)
        strcat(ARINC,Signbits);
        strcat(ARINC,bnr);
        strcat(ARINC,Sdi);
        strcat(ARINC,LabelRev);
        ARINC[32] = '\0';
    }
    
    printf("ARINC 429 : %s\n",ARINC);//Final ARINC429 Data Frame
    uint32_t Ans = Final_destination(ARINC);
    printf("%u\n",Ans);
    return 0;
}


