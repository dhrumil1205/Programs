#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include "arinc.h"
#define LBUS_SIZE 8
char *rev(char *s)
{
    char *str2 = malloc(sizeof(char)*LBUS_SIZE);
    memset(str2,0,sizeof(str2));
    int i=0;
    for(int j=8;j>0;j--)
    {
       str2[i]=s[j];
       i++;
    }
    str2[LBUS_SIZE] = '\0';
    return str2;
}
