#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdint.h>
#include<math.h>
#include "arinc.h"
#define DBUS_SIZE 19

char *deci2BNR(char *s,float range,int sigbits){
   
    char *str = malloc(sizeof(char)*DBUS_SIZE);
    memset(str,0,sizeof(char)*DBUS_SIZE);
    int data = atoi(s); //char to int
    int arr[sigbits],sum=0;
    static int arr2[DBUS_SIZE];
    int i=0,k=0;
    if(data>=0) //29th bit used to indicate data is + or -
    {
        strcat(str,"0");
    }
    else{
        strcat(str,"1");
    }
    for(int i=0;i<sigbits;i++) //scale the range upto sigbits
    {
        arr[i]=range/pow(2,i+1);
        //printf("%d\n",arr[i]);
    }
    i=0;
    while(sum!=data)
    {
            if(arr[i]>data) 
            {
                sum = 0;
            }
            else
            {
                sum = sum + arr[i];
                if(sum > data) //check wheather sum is not greater than data
                {
                    sum = sum - arr[i]; //delete particular scale factor from sum
                }
                else
                {
                    arr2[k]=i; //stores the index of scale factors which are used in sum
                    k++;
                }
            }
            i++;
    }
    //printf("%d\n",k);
    for(int j=0;j<DBUS_SIZE-1;j++)
    {
        int count = 0;
        for(int h=0;h<k;h++)
        {
            if(j==arr2[h])
            {
                strcat(str,"1");
                count=0;
                break;
            }
            else
            {
                count=1;
            }
        }
        if(count==1)
        {
            strcat(str,"0");
        }
        
    }
    //printf("Sum is :%d\n",sum);
    //printf("String is :%s\n",str);
    //printf("Length is : %d\n",strlen(str));
    return str;
}