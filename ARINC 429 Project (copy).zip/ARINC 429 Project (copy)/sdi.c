#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include "arinc.h"

char* validsdi(int sdi)
{
    char* str = malloc(sizeof(char)*3);
    memset(str,0,sizeof(str));
    switch(sdi)
        {
        case 0:
            strcat(str,"00");
            break;
        case 1:
            strcat(str,"01");
            break;
        case 2:
            strcat(str,"10");
            break;
        case 3:
            strcat(str,"11");
            break;       
        }
    str[3]='\0';
    return str;
}