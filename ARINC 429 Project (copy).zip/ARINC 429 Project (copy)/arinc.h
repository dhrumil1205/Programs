#include <stdint.h>
char *deci2BCD(char *,int);
char *rev(char *);
void paritybit(char*,char*,char*,char*);
char *validation(char*, char*,char*,float*,int*);
char *deci2BNR(char *,float,int);
uint32_t Final_destination(char *);
char *validssm(char*,char*,int);
char *validsdi(int);
