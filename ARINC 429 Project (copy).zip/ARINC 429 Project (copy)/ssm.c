#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include "arinc.h"

char* validssm(char* data,char* valid,int Sigbits)
{
    char* str = malloc(sizeof(char)*3);
    memset(str,0,sizeof(str));
    if(strcmp(valid,"BCD")==0)
    {
        if(atoi(data)>=0 && Sigbits!=0)
        {
            printf("Invalid SSM bits\n");
            printf("ARINC 429 SSM Bits (30-31 Bits) :");//user input ssm bits
            scanf("%d",&Sigbits);
        }
        if(atoi(data)<0 && Sigbits!=3)
        {
            printf("Invalid SSM bits\n");
            printf("ARINC 429 SSM Bits (30-31 Bits) :");//user input ssm bits
            scanf("%d",&Sigbits);
        }
        switch (Sigbits)
        {
        case 0:
            strcat(str,"00");
            break;
        case 1:
            strcat(str,"01");
            break;
        case 2:
            strcat(str,"10");
            break;
        case 3:
            strcat(str,"11");
            break;       
        }
    }
    if(strcmp(valid,"BNR")==0)
    {
        switch (Sigbits)
        {
        case 0:
            strcat(str,"00");
            break;
        case 1:
            strcat(str,"01");
            break;
        case 2:
            strcat(str,"10");
            break;
        case 3:
            strcat(str,"11");
            break;       
        }
    }
str[3]='\0';
return str;  
}
 
    