#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdint.h>
#include "arinc.h"
#define DBUS_SIZE 19
#define LBUS_SIZE 8
char *deci2BCD(char* s,int size)
{
    int j=0;
    char *str = malloc(sizeof(char)*size);
    memset(str,0,sizeof(str));
    //Decimal to BCD Coversion
    while(s[j]!='\0')
        {
            switch(s[j])
            {
            case '0':
                if(size==LBUS_SIZE || j==0 || ((atoi(s)<0) && j==1))
                    strcat(str,"000");
                else
                    strcat(str, "0000");
                break;
            case '1':
                 if(size==LBUS_SIZE || j==0 || ((atoi(s)<0) && j==1))
                    strcat(str,"001");
                else
                    strcat(str, "0001");
                break;
            case '2':
                if(size==LBUS_SIZE || j==0 || ((atoi(s)<0) && j==1))
                    strcat(str,"010");
                else
                    strcat(str, "0010");
                break;
            case '3':
                 if(size==LBUS_SIZE || j==0 || ((atoi(s)<0) && j==1))
                    strcat(str,"011");
                else
                    strcat(str, "0011");
                break;
            case '4':
                 if(size==LBUS_SIZE || j==0 || ((atoi(s)<0) && j==1))
                    strcat(str,"100");
                else
                    strcat(str, "0100");
                break;
            case '5' :
                if(size==LBUS_SIZE || j==0 || ((atoi(s)<0) && j==1))
                    strcat(str,"101");
                else
                    strcat(str, "0101");
                break;
            case '6':
                if(size==LBUS_SIZE || j==0 || ((atoi(s)<0) && j==1))
                    strcat(str,"110");
                else
                    strcat(str, "0110");
                break;
            case '7':
                 if(size==LBUS_SIZE || j==0 || ((atoi(s)<0) && j==1))
                    strcat(str,"111");
                else
                    strcat(str, "0111");
                break;
            case '8':
                strcat(str, "1000");
                break;
            case '9':
                strcat(str, "1001");
                break;
            }
            j++;
        }
        
        //ending zeros(PADS);
        if(size==DBUS_SIZE && strlen(s)!=6)
    {
    	if(atoi(s)>=0 && strlen(s)!=5)//for positive data
    	{
        	for(int i = 0; i <= 19 - strlen(s)*4 ; i++)
	    	{
            		strcat(str, "0");
        	}
        }
        if(atoi(s)<0)//for negative data
    	{
        	for(int i = 0; i <= 19 - (strlen(s)-1)*4 ; i++)
	    	{
            		strcat(str, "0");
        	}
        }
    }
    return str;
}
